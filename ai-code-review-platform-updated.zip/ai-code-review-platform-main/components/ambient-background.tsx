'use client'

import { useEffect, useRef } from 'react'

/**
 * Fixed, full-viewport backdrop: three blurred color blobs that drift on
 * their own (blob-float) and additionally shift with cursor position for a
 * subtle parallax/3D-depth feel, plus a faint perspective grid. Pointer-events
 * are disabled throughout so it never intercepts clicks. Respects
 * prefers-reduced-motion by skipping the pointer listener entirely.
 */
export function AmbientBackground() {
  const rootRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const root = rootRef.current
    if (!root) return
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return

    let raf = 0
    const handleMove = (e: PointerEvent) => {
      const x = e.clientX / window.innerWidth - 0.5
      const y = e.clientY / window.innerHeight - 0.5
      cancelAnimationFrame(raf)
      raf = requestAnimationFrame(() => {
        root.style.setProperty('--parallax-x', `${x * 36}px`)
        root.style.setProperty('--parallax-y', `${y * 36}px`)
      })
    }
    window.addEventListener('pointermove', handleMove)
    return () => {
      window.removeEventListener('pointermove', handleMove)
      cancelAnimationFrame(raf)
    }
  }, [])

  return (
    <div
      ref={rootRef}
      aria-hidden="true"
      className="pointer-events-none fixed inset-0 -z-10 overflow-hidden"
      style={{ ['--parallax-x' as string]: '0px', ['--parallax-y' as string]: '0px' }}
    >
      {/* violet blob, top-left */}
      <div
        className="absolute -left-24 -top-32 h-[520px] w-[520px]"
        style={{ transform: 'translate3d(calc(var(--parallax-x) * 0.6), calc(var(--parallax-y) * 0.6), 0)' }}
      >
        <div className="h-full w-full animate-[blob-float_16s_ease-in-out_infinite] rounded-full bg-[var(--scan-violet)]/20 blur-[120px]" />
      </div>
      {/* cyan blob, top-right */}
      <div
        className="absolute -right-20 top-[8%] h-[420px] w-[420px]"
        style={{ transform: 'translate3d(calc(var(--parallax-x) * -0.4), calc(var(--parallax-y) * -0.4), 0)' }}
      >
        <div className="h-full w-full animate-[blob-float_20s_ease-in-out_infinite_reverse] rounded-full bg-[var(--scan-cyan)]/15 blur-[110px]" />
      </div>
      {/* brand-teal blob, bottom */}
      <div
        className="absolute -bottom-32 left-[18%] h-[480px] w-[480px]"
        style={{ transform: 'translate3d(calc(var(--parallax-x) * 0.3), calc(var(--parallax-y) * 0.3), 0)' }}
      >
        <div className="h-full w-full animate-[blob-float_24s_ease-in-out_infinite] rounded-full bg-[var(--primary)]/10 blur-[130px]" />
      </div>
      {/* faint depth grid, fading toward the top */}
      <div
        className="absolute inset-0 opacity-[0.15]"
        style={{
          backgroundImage:
            'linear-gradient(var(--border) 1px, transparent 1px), linear-gradient(90deg, var(--border) 1px, transparent 1px)',
          backgroundSize: '56px 56px',
          maskImage: 'radial-gradient(ellipse 60% 50% at 50% 0%, black, transparent 75%)',
          WebkitMaskImage: 'radial-gradient(ellipse 60% 50% at 50% 0%, black, transparent 75%)',
        }}
      />
    </div>
  )
}
