'use client'

import { useEffect, useRef, useState } from 'react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { CodeEditor } from '@/components/review/code-editor'
import { ScanFrame } from '@/components/review/scan-frame'
import { ReviewResults } from '@/components/review/review-results'
import {
  LANGUAGES,
  MODES,
  detectLanguageFromContent,
  detectLanguageFromFilename,
  getLanguage,
  type ReviewMode,
} from '@/lib/languages'
import type { ReviewResult } from '@/lib/review-types'
import { cn } from '@/lib/utils'
import { Bug, BookOpen, Wrench, Upload, Play, Loader2, ScanLine } from 'lucide-react'

const MODE_ICONS = { detect: Bug, explain: BookOpen, fix: Wrench }

const SAMPLE_CODE = `function getUserData(userId) {
  var query = "SELECT * FROM users WHERE id = " + userId;
  db.execute(query, function(err, result) {
    if (err) console.log(err);
    var data = result[0];
    for (var i = 0; i < data.orders.length; i++) {
      for (var j = 0; j < data.orders.length; j++) {
        if (data.orders[i].id == data.orders[j].id && i != j) {
          data.orders.splice(j, 1);
        }
      }
    }
    return data;
  });
}`

// Minimum characters of pasted/typed code before we trust the auto-detector.
// Below this, short snippets produce too many false positives.
const MIN_CHARS_FOR_DETECTION = 25
// Debounce so detection runs once code settles, not on every keystroke.
const DETECTION_DEBOUNCE_MS = 500

export function ReviewWorkspace() {
  const [code, setCode] = useState('')
  const [language, setLanguage] = useState('javascript')
  const [mode, setMode] = useState<ReviewMode>('detect')
  const [title, setTitle] = useState('')
  const [sourceType, setSourceType] = useState<'paste' | 'upload'>('paste')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<ReviewResult | null>(null)
  const [tilt, setTilt] = useState<Record<string, React.CSSProperties>>({})
  const fileInputRef = useRef<HTMLInputElement>(null)
  const lastDetectedRef = useRef<string | null>(null)

  // Live language auto-detection: whenever the code content settles, scan it
  // for language signals. If it confidently matches a language other than
  // the last one we auto-detected, switch the dropdown and toast which
  // language was found.
  useEffect(() => {
    const trimmed = code.trim()
    if (trimmed.length < MIN_CHARS_FOR_DETECTION) {
      lastDetectedRef.current = null
      return
    }
    const timeout = setTimeout(() => {
      const detected = detectLanguageFromContent(code)
      if (!detected || detected.id === lastDetectedRef.current) return
      lastDetectedRef.current = detected.id
      setLanguage((current) => {
        if (current === detected.id) return current
        toast.info(`Detected ${detected.label} — switched language automatically`, {
          icon: <ScanLine className="h-4 w-4" aria-hidden="true" />,
        })
        return detected.id
      })
    }, DETECTION_DEBOUNCE_MS)
    return () => clearTimeout(timeout)
  }, [code])

  const handleFile = async (file: File) => {
    if (file.size > 200_000) {
      toast.error('File too large (max 200KB)')
      return
    }
    const text = await file.text()
    setCode(text)
    setSourceType('upload')
    setTitle(file.name)
    const detected = detectLanguageFromFilename(file.name)
    if (detected) {
      setLanguage(detected.id)
      // Prevent the content-detector from immediately re-toasting a
      // possibly-different guess right after we just set it from filename.
      lastDetectedRef.current = detected.id
    }
    toast.success(`Loaded ${file.name}${detected ? ` (${detected.label})` : ''}`)
  }

  const handleTiltMove = (id: string) => (e: React.MouseEvent<HTMLButtonElement>) => {
    const rect = e.currentTarget.getBoundingClientRect()
    const px = (e.clientX - rect.left) / rect.width
    const py = (e.clientY - rect.top) / rect.height
    const rotateY = (px - 0.5) * 8
    const rotateX = (0.5 - py) * 8
    setTilt((t) => ({
      ...t,
      [id]: {
        transform: `perspective(600px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`,
        ['--glow-x' as string]: `${px * 100}%`,
        ['--glow-y' as string]: `${py * 100}%`,
      },
    }))
  }

  const handleTiltLeave = (id: string) => () => {
    setTilt((t) => ({
      ...t,
      [id]: { transform: 'perspective(600px) rotateX(0deg) rotateY(0deg)' },
    }))
  }

  const runReview = async () => {
    if (!code.trim()) {
      toast.error('Paste or upload some code first')
      return
    }
    setLoading(true)
    setResult(null)
    try {
      const res = await fetch('/api/review', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code, language, mode, title: title || undefined, sourceType }),
      })
      const data = await res.json()
      if (!res.ok) {
        toast.error(data.error || 'Review failed')
        return
      }
      setResult(data.result)
      if (data.result.isCode) {
        toast.success('Review complete and saved to your history')
      }
    } catch {
      toast.error('Network error. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="mx-auto max-w-7xl px-4 py-6">
      <div className="mb-6 flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Code Review Workspace</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Paste code or upload a file, pick a mode, and get an instant AI review.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Input
            placeholder="Review title (optional)"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-48"
            aria-label="Review title"
          />
          <Select value={language} onValueChange={(v) => v && setLanguage(v)}>
            <SelectTrigger className="w-44" aria-label="Programming language">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {LANGUAGES.map((l) => (
                <SelectItem key={l.id} value={l.id}>
                  {l.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Mode selector */}
      <div className="mb-4 grid gap-2 sm:grid-cols-3" role="radiogroup" aria-label="Review mode">
        {MODES.map((m) => {
          const Icon = MODE_ICONS[m.id]
          const active = mode === m.id
          return (
            <button
              key={m.id}
              type="button"
              role="radio"
              aria-checked={active}
              onClick={() => setMode(m.id)}
              onMouseMove={handleTiltMove(m.id)}
              onMouseLeave={handleTiltLeave(m.id)}
              style={tilt[m.id]}
              className={cn(
                'group relative flex items-start gap-3 overflow-hidden rounded-lg border p-3 text-left transition-[background-color,border-color] duration-150 ease-out will-change-transform motion-reduce:!transform-none',
                active
                  ? 'border-primary bg-primary/10'
                  : 'border-border bg-card hover:border-muted-foreground/40',
              )}
            >
              <span
                aria-hidden="true"
                className="pointer-events-none absolute inset-0 rounded-lg opacity-0 transition-opacity duration-200 group-hover:opacity-100"
                style={{
                  background:
                    'radial-gradient(180px circle at var(--glow-x, 50%) var(--glow-y, 50%), color-mix(in oklch, var(--scan-cyan) 16%, transparent), transparent 70%)',
                }}
              />
              <Icon
                className={cn('relative mt-0.5 h-5 w-5 shrink-0', active ? 'text-primary' : 'text-muted-foreground')}
                aria-hidden="true"
              />
              <span className="relative">
                <span className="block text-sm font-semibold text-foreground">{m.label}</span>
                <span className="block text-xs leading-relaxed text-muted-foreground">{m.description}</span>
              </span>
            </button>
          )
        })}
      </div>

      {/* Editor, wrapped in the Sentinel Scan frame */}
      <ScanFrame active={loading}>
        <div className="flex items-center justify-between border-b border-border bg-card px-3 py-2">
          <span className="font-mono text-xs text-muted-foreground">
            {getLanguage(language)?.label} — {code.split('\n').length} lines
          </span>
          <div className="flex items-center gap-2">
            <input
              ref={fileInputRef}
              type="file"
              className="sr-only"
              onChange={(e) => {
                const f = e.target.files?.[0]
                if (f) handleFile(f)
                e.target.value = ''
              }}
              aria-label="Upload code file"
            />
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                setCode(SAMPLE_CODE)
                setLanguage('javascript')
                setSourceType('paste')
              }}
            >
              Try sample
            </Button>
            <Button variant="outline" size="sm" onClick={() => fileInputRef.current?.click()}>
              <Upload className="h-4 w-4" aria-hidden="true" />
              Upload file
            </Button>
            <Button size="sm" onClick={runReview} disabled={loading}>
              {loading ? (
                <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
              ) : (
                <Play className="h-4 w-4" aria-hidden="true" />
              )}
              {loading ? 'Reviewing…' : 'Run review'}
            </Button>
          </div>
        </div>
        <div className="h-[420px]">
          <CodeEditor
            value={code}
            onChange={setCode}
            language={getLanguage(language)?.monacoId || 'plaintext'}
          />
        </div>
      </ScanFrame>

      {/* Results */}
      <div className="mt-6">
        <ReviewResults
          result={result}
          loading={loading}
          mode={mode}
          code={code}
          language={language}
          title={title || `${getLanguage(language)?.label} review`}
          onApplyFix={(fixed) => {
            setCode(fixed)
            toast.success('Fixed code applied to editor')
          }}
        />
      </div>
    </main>
  )
}
