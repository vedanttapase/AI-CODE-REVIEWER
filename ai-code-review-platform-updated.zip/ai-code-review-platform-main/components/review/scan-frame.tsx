'use client'

import type { ReactNode } from 'react'
import { cn } from '@/lib/utils'

/**
 * "Sentinel Scan" frame — the signature visual of the review workspace.
 * A slowly rotating conic-gradient glow rings the editor at all times (the
 * platform is always watching your code), and while `active` is true a
 * horizontal beam sweeps down over the content, like the code is being
 * scanned in real time.
 */
export function ScanFrame({
  children,
  active,
  className,
}: {
  children: ReactNode
  active?: boolean
  className?: string
}) {
  return (
    <div className={cn('relative rounded-lg', className)}>
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -inset-px animate-[border-spin_6s_linear_infinite] rounded-lg opacity-40 blur-[2px] transition-opacity duration-500"
        style={{
          background:
            'conic-gradient(from var(--angle), transparent 0% 75%, var(--scan-cyan) 85%, var(--scan-violet) 92%, transparent 100%)',
        }}
      />
      <div className="relative overflow-hidden rounded-lg border border-border bg-background">
        {children}
        {active && (
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-x-0 top-0 z-10 h-24 animate-[scan-sweep_1.6s_ease-in-out_infinite]"
            style={{
              background:
                'linear-gradient(to bottom, transparent, color-mix(in oklch, var(--scan-cyan) 30%, transparent), transparent)',
            }}
          />
        )}
        <span
          aria-hidden="true"
          className="pointer-events-none absolute left-2 top-2 h-4 w-4 border-l-2 border-t-2"
          style={{ borderColor: 'color-mix(in oklch, var(--scan-cyan) 70%, transparent)' }}
        />
        <span
          aria-hidden="true"
          className="pointer-events-none absolute right-2 top-2 h-4 w-4 border-r-2 border-t-2"
          style={{ borderColor: 'color-mix(in oklch, var(--scan-cyan) 70%, transparent)' }}
        />
        <span
          aria-hidden="true"
          className="pointer-events-none absolute bottom-2 left-2 h-4 w-4 border-b-2 border-l-2"
          style={{ borderColor: 'color-mix(in oklch, var(--scan-cyan) 70%, transparent)' }}
        />
        <span
          aria-hidden="true"
          className="pointer-events-none absolute bottom-2 right-2 h-4 w-4 border-b-2 border-r-2"
          style={{ borderColor: 'color-mix(in oklch, var(--scan-cyan) 70%, transparent)' }}
        />
      </div>
    </div>
  )
}
