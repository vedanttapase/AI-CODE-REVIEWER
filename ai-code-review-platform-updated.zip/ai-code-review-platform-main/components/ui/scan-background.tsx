/**
 * Ambient "sentinel radar" backdrop: a receding grid horizon, two slow-drifting
 * color beacons, and a faint vertical sweep. Pure CSS, no client JS needed.
 * Render once near the root of a page — it's `fixed` and sits behind content.
 */
export function ScanBackground() {
  return (
    <div className="scan-backdrop" aria-hidden="true">
      <div className="scan-orb scan-orb--sentinel" />
      <div className="scan-orb scan-orb--beacon" />
      <div className="scan-sweep" />
    </div>
  )
}
