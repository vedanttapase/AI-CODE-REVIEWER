export interface LanguageDef {
  id: string
  label: string
  monacoId: string
  extensions: string[]
}

export const LANGUAGES: LanguageDef[] = [
  { id: 'javascript', label: 'JavaScript', monacoId: 'javascript', extensions: ['.js', '.mjs', '.cjs', '.jsx'] },
  { id: 'typescript', label: 'TypeScript', monacoId: 'typescript', extensions: ['.ts', '.tsx', '.mts'] },
  { id: 'python', label: 'Python', monacoId: 'python', extensions: ['.py', '.pyw'] },
  { id: 'java', label: 'Java', monacoId: 'java', extensions: ['.java'] },
  { id: 'c', label: 'C', monacoId: 'c', extensions: ['.c', '.h'] },
  { id: 'cpp', label: 'C++', monacoId: 'cpp', extensions: ['.cpp', '.cc', '.cxx', '.hpp'] },
  { id: 'csharp', label: 'C#', monacoId: 'csharp', extensions: ['.cs'] },
  { id: 'go', label: 'Go', monacoId: 'go', extensions: ['.go'] },
  { id: 'rust', label: 'Rust', monacoId: 'rust', extensions: ['.rs'] },
  { id: 'ruby', label: 'Ruby', monacoId: 'ruby', extensions: ['.rb'] },
  { id: 'php', label: 'PHP', monacoId: 'php', extensions: ['.php'] },
  { id: 'swift', label: 'Swift', monacoId: 'swift', extensions: ['.swift'] },
  { id: 'kotlin', label: 'Kotlin', monacoId: 'kotlin', extensions: ['.kt', '.kts'] },
  { id: 'scala', label: 'Scala', monacoId: 'scala', extensions: ['.scala'] },
  { id: 'dart', label: 'Dart', monacoId: 'dart', extensions: ['.dart'] },
  { id: 'r', label: 'R', monacoId: 'r', extensions: ['.r', '.R'] },
  { id: 'sql', label: 'SQL', monacoId: 'sql', extensions: ['.sql'] },
  { id: 'shell', label: 'Shell / Bash', monacoId: 'shell', extensions: ['.sh', '.bash', '.zsh'] },
  { id: 'html', label: 'HTML', monacoId: 'html', extensions: ['.html', '.htm'] },
  { id: 'css', label: 'CSS', monacoId: 'css', extensions: ['.css', '.scss', '.less'] },
  { id: 'perl', label: 'Perl', monacoId: 'perl', extensions: ['.pl', '.pm'] },
  { id: 'lua', label: 'Lua', monacoId: 'lua', extensions: ['.lua'] },
  { id: 'haskell', label: 'Haskell', monacoId: 'haskell', extensions: ['.hs'] },
  { id: 'elixir', label: 'Elixir', monacoId: 'elixir', extensions: ['.ex', '.exs'] },
  { id: 'objective-c', label: 'Objective-C', monacoId: 'objective-c', extensions: ['.m', '.mm'] },
  { id: 'matlab', label: 'MATLAB', monacoId: 'matlab', extensions: ['.mat'] },
  { id: 'julia', label: 'Julia', monacoId: 'julia', extensions: ['.jl'] },
  { id: 'solidity', label: 'Solidity', monacoId: 'sol', extensions: ['.sol'] },
]

export function detectLanguageFromFilename(filename: string): LanguageDef | undefined {
  const lower = filename.toLowerCase()
  return LANGUAGES.find((l) => l.extensions.some((ext) => lower.endsWith(ext)))
}

/**
 * Content-based language detection. Scores a code sample against a set of
 * signal patterns per language and returns the strongest match. Checked in
 * priority order so more specific languages (e.g. TypeScript, C++) win over
 * the generic superset they sit inside (JavaScript, C).
 */
interface DetectionRule {
  id: string
  patterns: RegExp[]
}

const DETECTION_RULES: DetectionRule[] = [
  {
    id: 'html',
    patterns: [/<!doctype html>/i, /<\/html>/i, /<html[\s>]/i, /<head[\s>]/i, /<body[\s>]/i, /<div[\s>]/i, /<span[\s>]/i],
  },
  {
    id: 'css',
    patterns: [/^\s*[.#]?[\w-]+\s*\{/m, /^\s*[a-z-]+\s*:\s*[^;{}]+;\s*$/m, /@media\s*\(/, /^\s*@import\s+/m],
  },
  {
    id: 'typescript',
    patterns: [/:\s*(string|number|boolean|any|void|unknown)\b/, /\binterface\s+\w+/, /\bimplements\s+\w+\b/, /:\s*React\.FC/, /\benum\s+\w+/, /<\w+>\s*\(/],
  },
  {
    id: 'python',
    patterns: [/^\s*def\s+\w+\(.*\)\s*:/m, /^\s*import\s+\w+/m, /^\s*from\s+\w+\s+import/m, /\bprint\(/, /^\s*elif\b/m, /\bself\b/, /^\s*except\s+\w*.*:/m],
  },
  {
    id: 'rust',
    patterns: [/\bfn\s+main\s*\(\)/, /\blet\s+mut\b/, /println!\(/, /^\s*use\s+std::/m, /->\s*\w+\s*\{/],
  },
  {
    id: 'go',
    patterns: [/^\s*package\s+main/m, /\bfunc\s+main\s*\(\)/, /fmt\.Println/, /:=\s*/, /^\s*import\s*\(/m],
  },
  {
    id: 'csharp',
    patterns: [/\busing\s+System;/, /\bnamespace\s+\w+/, /Console\.WriteLine/, /\bpublic\s+class\s+\w+/, /\bpublic\s+static\s+void\s+Main\(/],
  },
  {
    id: 'cpp',
    patterns: [/#include\s*<\w+>/, /\bstd::/, /\bcout\s*<</, /\bcin\s*>>/, /\bint\s+main\s*\(/],
  },
  {
    id: 'c',
    patterns: [/#include\s*<\w+\.h>/, /\bprintf\(/, /\bint\s+main\s*\(/, /\bmalloc\(/],
  },
  {
    id: 'java',
    patterns: [/\bpublic\s+class\s+\w+/, /\bpublic\s+static\s+void\s+main\(/, /System\.out\.println/, /^\s*import\s+java\./m],
  },
  {
    id: 'kotlin',
    patterns: [/\bfun\s+main\s*\(/, /\bval\s+\w+\s*[:=]/, /\bprintln\(/, /^\s*package\s+[\w.]+\s*$/m],
  },
  {
    id: 'swift',
    patterns: [/\bfunc\s+\w+\(/, /\bvar\s+\w+\s*:/, /\bimport\s+(UIKit|Foundation|SwiftUI)\b/, /\bguard\s+let\b/],
  },
  {
    id: 'ruby',
    patterns: [/^\s*def\s+\w+/m, /^\s*end\s*$/m, /\bputs\s+/, /^\s*require\s+'/m, /\battr_accessor\b/],
  },
  {
    id: 'php',
    patterns: [/<\?php/, /\$\w+\s*=/, /\becho\s+/, /\bfunction\s+\w+\s*\(/],
  },
  {
    id: 'sql',
    patterns: [/\bSELECT\s+.+\bFROM\b/i, /\bINSERT\s+INTO\b/i, /\bCREATE\s+TABLE\b/i, /\bUPDATE\s+\w+\s+SET\b/i],
  },
  {
    id: 'shell',
    patterns: [/^#!\/bin\/(ba|z)?sh/m, /^#!\/usr\/bin\/env\s+(bash|sh)/m, /^\s*fi\s*$/m, /^\s*then\s*$/m, /\becho\s+"/],
  },
  {
    id: 'javascript',
    patterns: [/\bconst\s+\w+\s*=/, /\blet\s+\w+\s*=/, /\bfunction\s*\w*\s*\(/, /=>\s*\{?/, /console\.log\(/, /\brequire\(/, /\bexport\s+(default\s+)?/, /document\./, /\bwindow\./],
  },
]

const DETECTION_PRIORITY = DETECTION_RULES.map((r) => r.id)

export function detectLanguageFromContent(code: string): LanguageDef | undefined {
  const sample = code.slice(0, 5000).trim()
  if (sample.length < 20) return undefined

  const scores = new Map<string, number>()
  for (const rule of DETECTION_RULES) {
    let score = 0
    for (const pattern of rule.patterns) {
      if (pattern.test(sample)) score += 1
    }
    if (score > 0) scores.set(rule.id, score)
  }

  // Strong match first (>=2 independent signals), in priority order so
  // specific languages win over the generic one they overlap with.
  for (const id of DETECTION_PRIORITY) {
    if ((scores.get(id) ?? 0) >= 2) return getLanguage(id)
  }
  // Fall back to a single weak signal for short snippets.
  for (const id of DETECTION_PRIORITY) {
    if ((scores.get(id) ?? 0) >= 1) return getLanguage(id)
  }
  return undefined
}

export function getLanguage(id: string): LanguageDef | undefined {
  return LANGUAGES.find((l) => l.id === id)
}

export type ReviewMode = 'detect' | 'explain' | 'fix'

export const MODES: { id: ReviewMode; label: string; description: string }[] = [
  {
    id: 'detect',
    label: 'Detect',
    description: 'Find bugs, security vulnerabilities, and code smells',
  },
  {
    id: 'explain',
    label: 'Explain',
    description: 'Line-by-line explanation of what the code does',
  },
  {
    id: 'fix',
    label: 'Fix',
    description: 'Auto-fix issues and return corrected code with a diff',
  },
]
